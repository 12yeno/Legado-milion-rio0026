function previewCV(){
  const name=document.getElementById('cvName').value||'Nome do participante';
  const role=document.getElementById('cvRole').value||'Objetivo profissional';
  const phone=document.getElementById('cvPhone').value||'Telefone';
  const email=document.getElementById('cvEmail').value||'Email';
  const edu=document.getElementById('cvEdu').value||'Formação académica';
  const exp=document.getElementById('cvExp').value||'Experiência profissional';
  const skills=document.getElementById('cvSkills').value||'Competências';
  document.querySelector('#cvPreview h3').textContent=name;
  document.querySelector('#cvPreview .cv-top p').textContent=role;
  document.getElementById('pRole').textContent=role;
  document.getElementById('pEdu').textContent=edu;
  document.getElementById('pExp').textContent=exp;
  document.getElementById('pSkills').textContent=skills;
  document.getElementById('pContact').textContent=phone+' • '+email;
  document.getElementById('cvPreview').scrollIntoView({behavior:'smooth',block:'center'});
}
document.querySelector('.menu')?.addEventListener('click',()=>{const n=document.querySelector('nav'); n.style.display=n.style.display==='flex'?'none':'flex'; n.style.flexDirection='column'; n.style.position='absolute'; n.style.right='5%'; n.style.top='68px'; n.style.background='#0b0d10'; n.style.padding='18px'; n.style.borderRadius='12px';});
